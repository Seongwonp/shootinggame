#ifndef GAME_FUNCTIONS_H
#define GAME_FUNCTIONS_H

void help(); //도움말 창 출력
void startmenu(); //매뉴 화면 출력
void playerdraw(int x, int y); //플레이어 아이콘
void erasePlayer(int x, int y); //지우기

#endif /* GAME_FUNCTIONS.H */
